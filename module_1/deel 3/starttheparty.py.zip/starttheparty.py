gastheer = True
gasten = True
drank = True
chips = True

if gasten or gastheer and drank and chips == True :
    print('Start the Party')
else:
    print('No Party')
